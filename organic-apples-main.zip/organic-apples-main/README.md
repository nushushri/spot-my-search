# organic-apples
Datavant Future of Healthcare Hackathon Submission 2022!

Running instructions:
Please run this tool with the developer console open. If you type in "instagram", "twitter", or "facebook" into the Google search bar, you should see that a warning pops up. If no warning comes up, we suggest refreshing.

Tutorials used:
https://developer.chrome.com/docs/extensions/mv3/messaging/: referenced example for querying tabs in popup.js and adding listener in content-script.js, but modified with our own functions as necessary
License: https://creativecommons.org/licenses/by-sa/4.0/

Chrome extension starter code: https://developer.chrome.com/docs/extensions/mv3/getstarted/ 
License: https://creativecommons.org/licenses/by-sa/4.0/

AI/ML tutorials: 
https://stackabuse.com/python-for-nlp-movie-sentiment-analysis-using-deep-learning-in-keras/
https://www.datacamp.com/tutorial/naive-bayes-scikit-learn
